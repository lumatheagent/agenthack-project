# Task Classifier for UiPath Automation

This Python script integrates with the OpenAI API to classify and extract information from free-text action items for use in UiPath automation processes.

## Features

- **Task Classification**: Automatically categorizes tasks into predefined categories
- **Information Extraction**: Extracts structured data based on task category
- **JSON Output**: Returns consistent JSON format for UiPath integration
- **Error Handling**: Robust error handling and validation

## Supported Categories

1. **code_review**: Extracts `project_name`
2. **ticket_management**: Extracts `ticket_id` or brief ticket summary
3. **orchestrator_management**: Extracts `job_name` or relevant orchestrator element
4. **calendar**: Extracts `meeting_time` and `attendees`
5. **unclassified**: For tasks that don't clearly fit other categories

## Output Format

The script returns a JSON object with this exact structure:

```json
{
  "category": "<one of: code_review | ticket_management | orchestrator_management | calendar | unclassified>",
  "details": {
    "project_name": "",
    "ticket_id": "",
    "job_name": "",
    "meeting_time": "",
    "attendees": [],
    "description": "..."
  }
}
```

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure OpenAI API Key

Create a `.env` file in the project root:

```
OPENAI_API_KEY=your_actual_openai_api_key_here
```

You can get your API key from [OpenAI Platform](https://platform.openai.com/api-keys).

### 3. Verify Installation

```bash
python task_classifier.py "Please schedule a meeting with the QA team tomorrow at 2pm"
```

## Usage

### Command Line

```bash
python task_classifier.py "Your task description here"
```

### Python Script Integration

```python
from task_classifier import TaskClassifier

# Initialize classifier
classifier = TaskClassifier()

# Classify a task
task_description = "Please review the code for the user authentication module"
result = classifier.classify_task(task_description)

print(result)
```

### UiPath Integration

In UiPath, you can call this script using the "Invoke Code" activity:

1. Set the **Language** to `Python`
2. Set the **Code** to:
   ```python
   import sys
   import json
   from task_classifier import TaskClassifier
   
   # Get task description from UiPath variable
   task_description = in_task_description
   
   # Classify the task
   classifier = TaskClassifier()
   result = classifier.classify_task(task_description)
   
   # Return JSON string to UiPath
   out_result = json.dumps(result)
   ```

3. Set input/output arguments:
   - **Input**: `in_task_description` (String)
   - **Output**: `out_result` (String)

## Example Outputs

### Calendar Task
**Input**: "Please schedule a meeting with the QA team tomorrow at 2pm"

**Output**:
```json
{
  "category": "calendar",
  "details": {
    "project_name": "",
    "ticket_id": "",
    "job_name": "",
    "meeting_time": "tomorrow at 2pm",
    "attendees": ["QA team"],
    "description": "Schedule meeting with QA team tomorrow at 2pm"
  }
}
```

### Code Review Task
**Input**: "Review the authentication module in the user-service project"

**Output**:
```json
{
  "category": "code_review",
  "details": {
    "project_name": "user-service",
    "ticket_id": "",
    "job_name": "",
    "meeting_time": "",
    "attendees": [],
    "description": "Review authentication module in user-service project"
  }
}
```

### Ticket Management Task
**Input**: "Update ticket JIRA-123 with the latest status"

**Output**:
```json
{
  "category": "ticket_management",
  "details": {
    "project_name": "",
    "ticket_id": "JIRA-123",
    "job_name": "",
    "meeting_time": "",
    "attendees": [],
    "description": "Update ticket JIRA-123 with latest status"
  }
}
```

## Error Handling

The script includes comprehensive error handling:

- **API Key Missing**: Clear error message if OpenAI API key is not configured
- **Invalid JSON Response**: Handles malformed responses from OpenAI
- **Structure Validation**: Validates that the response matches the expected format
- **API Errors**: Graceful handling of OpenAI API errors

## Configuration Options

### Model Selection

You can specify different OpenAI models:

```python
classifier = TaskClassifier()
result = classifier.classify_task(task_description, model="gpt-3.5-turbo")
```

### Custom API Key

```python
classifier = TaskClassifier(api_key="your_custom_api_key")
```

## Troubleshooting

### Common Issues

1. **"OpenAI API key is required"**
   - Ensure you have created a `.env` file with your API key
   - Verify the API key is valid and has sufficient credits

2. **"Invalid JSON response from OpenAI"**
   - This usually indicates the model returned non-JSON content
   - The script will retry with a more explicit prompt

3. **"Error calling OpenAI API"**
   - Check your internet connection
   - Verify your OpenAI account has available credits
   - Ensure the API key has the necessary permissions

### Debug Mode

For debugging, you can modify the script to print the raw API response:

```python
# Add this line after the API call in classify_task method
print(f"Raw API response: {response_content}")
```

## License

This project is provided as-is for UiPath automation integration. 