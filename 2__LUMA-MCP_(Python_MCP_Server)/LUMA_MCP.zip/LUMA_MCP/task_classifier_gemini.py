import json
import os
import sys
from typing import Dict, Any, Optional
import google.generativeai as genai
from dotenv import load_dotenv
from datetime import datetime

# Load environment variables
load_dotenv()

class TaskClassifierGemini:
    """
    A class to classify and extract information from free-text action items using Google Gemini API.
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize the TaskClassifierGemini with Google Gemini API key.
        
        Args:
            api_key: Google Gemini API key. If not provided, will try to get from environment variable.
        """
        self.api_key = api_key or os.getenv('GEMINI_API_KEY')
        if not self.api_key:
            raise ValueError("Google Gemini API key is required. Set GEMINI_API_KEY environment variable or pass it to the constructor.")
        
        # Configure Gemini API
        genai.configure(api_key=self.api_key)  # type: ignore
        
        # Define the base system prompt template (without date)
        self.base_system_prompt = """You are a task classification assistant that analyzes free-text action items and categorizes them into specific types while extracting relevant structured information.

Your task is to:
1. Determine which category the task belongs to from: code_review, ticket_management, orchestrator_management, calendar, or unclassified
2. Extract relevant information based on the category
3. Return a JSON object with the exact structure specified

Categories and their required fields:
- code_review: extract project_name (for tasks involving reviewing completed processes, code, or development work before going live, including "ready to be reviewed", "needs review", "review completed work", or "code review")
- ticket_management: extract ticket_id or brief ticket summary (for tasks involving "turuncu hat", tickets, issues, or bug reports)
- orchestrator_management: extract job_name or relevant orchestrator element (for tasks involving automation jobs, workflows, server management or orchestrator processes)
- calendar: extract meeting_time, attendees (if present), and meeting_subject (if mentioned) (for tasks involving scheduling, meetings, or appointments)
- unclassified: when task doesn't clearly fit any category

Today's date is: {current_date}

For calendar tasks with meeting times:
- If the task mentions relative time (like "tomorrow at 2pm", "next Monday", "in 3 days"), convert it to absolute date in dd.MM.yyyy format
- If the task mentions specific time, include it in the format: dd.MM.yyyy HH:mm
- If no specific time is mentioned, use dd.MM.yyyy format
- Calculate dates carefully: "tomorrow" = today + 1 day, "next [day]" = next occurrence of that weekday

IMPORTANT: You must return ONLY valid JSON in this exact structure:
{{
  "category": "<one of: code_review | ticket_management | orchestrator_management | calendar | unclassified>",
  "details": {{
    "project_name": "",
    "ticket_id": "",
    "job_name": "",
    "meeting_time": "",
    "attendees": [],
    "meeting_subject": "",
    "description": "..."
  }}
}}

Rules:
- Leave fields empty ("") or empty arrays ([]) if not relevant to the category
- Always fill the description field with a brief summary
- If unclear, use "unclassified" category
- IMPORTANT: Any task mentioning "ready to be reviewed", "needs review", "review completed", or similar phrases should be classified as "code_review"
- For calendar tasks, always convert relative dates to absolute dates in dd.MM.yyyy format
- Return ONLY the JSON object, no additional text or explanations"""

    def classify_task(self, task_description: str, current_date: Optional[str] = None, model: str = "gemini-2.5-flash") -> Dict[str, Any]:
        """
        Classify a task and extract structured information.
        
        Args:
            task_description: The natural language task description
            current_date: Current date in dd.mm.yyyy format (optional, defaults to today)
            model: The Gemini model to use (default: gemini-2.5-flash)
            
        Returns:
            Dictionary containing the classification and extracted details
            
        Raises:
            Exception: If API call fails or response is invalid
        """
        # Use provided current_date or default to today
        if current_date is None:
            current_date = datetime.now().strftime("%d.%m.%Y")
        
        # Format the system prompt with the current date
        system_prompt = self.base_system_prompt.format(current_date=current_date)

        try:
            # Prepare the user message
            user_message = f"Please classify and extract information from this task: {task_description}"
            
            # Create the model
            model_instance = genai.GenerativeModel(model)  # type: ignore
            
            # Make API call to Gemini
            response = model_instance.generate_content(
                f"{system_prompt}\n\n{user_message}",
                generation_config=genai.GenerationConfig(  # type: ignore
                    temperature=0.1,  # Low temperature for consistent results
                    max_output_tokens=1000  # Increased to avoid truncated responses
                )
            )
            
            # Extract the response content with proper error handling
            if not response.candidates or not response.candidates[0].content.parts:
                raise Exception("No valid response from Gemini. The model may have filtered the content or could not generate a valid answer.")
            
            response_content = response.text
            if not response_content:
                raise Exception("Empty response from Gemini API")
            
            response_content = response_content.strip()
            
            # Remove markdown code blocks if present
            if response_content.startswith("```json"):
                response_content = response_content[7:]  # Remove "```json"
            if response_content.startswith("```"):
                response_content = response_content[3:]  # Remove "```"
            if response_content.endswith("```"):
                response_content = response_content[:-3]  # Remove trailing "```"
            
            response_content = response_content.strip()
            
            # Parse the JSON response
            try:
                result = json.loads(response_content)
                
                # Validate the structure
                self._validate_response_structure(result)
                
                return result
                
            except json.JSONDecodeError as e:
                # Check if response was truncated
                if "Unterminated string" in str(e) or len(response_content) < 50:
                    raise Exception(f"Response appears to be truncated. Please try again or check if the task description is too complex. Response: {response_content}")
                else:
                    raise Exception(f"Invalid JSON response from Gemini: {e}. Response: {response_content}")
                
        except Exception as e:
            raise Exception(f"Error calling Gemini API: {str(e)}")
    
    def _validate_response_structure(self, result: Dict[str, Any]) -> None:
        """
        Validate that the response has the correct structure.
        
        Args:
            result: The parsed JSON response
            
        Raises:
            ValueError: If structure is invalid
        """
        required_keys = ["category", "details"]
        valid_categories = ["code_review", "ticket_management", "orchestrator_management", "calendar", "unclassified"]
        required_detail_keys = ["project_name", "ticket_id", "job_name", "meeting_time", "attendees", "meeting_subject", "description"]
        
        # Check top-level structure
        for key in required_keys:
            if key not in result:
                raise ValueError(f"Missing required key: {key}")
        
        # Check category validity
        if result["category"] not in valid_categories:
            raise ValueError(f"Invalid category: {result['category']}. Must be one of: {valid_categories}")
        
        # Check details structure
        if not isinstance(result["details"], dict):
            raise ValueError("'details' must be a dictionary")
        
        for key in required_detail_keys:
            if key not in result["details"]:
                raise ValueError(f"Missing required detail key: {key}")
        
        # Validate attendees is a list
        if not isinstance(result["details"]["attendees"], list):
            raise ValueError("'attendees' must be a list")

def main():
    """
    Main function for command-line usage.
    """
    if len(sys.argv) != 2:
        print("Usage: python task_classifier_gemini.py \"<task description>\"")
        sys.exit(1)
    
    task_description = sys.argv[1]
    
    try:
        classifier = TaskClassifierGemini()
        result = classifier.classify_task(task_description)
        
        # Print the result as JSON for UiPath to consume
        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main() 