#!/usr/bin/env python3
"""
MCP (Model Context Protocol) Server for Task Classifier with Google Calendar Integration
"""

import asyncio
import json
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from dotenv import load_dotenv

import fastapi
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import google.generativeai as genai
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import pickle

# Load environment variables
load_dotenv()

# Google Calendar API setup
SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']
CREDENTIALS_FILE = 'credentials.json'
TOKEN_FILE = 'token.pickle'

class MCPRequest(BaseModel):
    """MCP request model"""
    method: str
    params: Optional[Dict[str, Any]] = None

class MCPResponse(BaseModel):
    """MCP response model"""
    result: Optional[Any] = None
    error: Optional[str] = None

class TaskClassifierMCP:
    """MCP Server for Task Classification with Google Calendar Integration"""
    
    def __init__(self):
        self.app = FastAPI(title="Task Classifier MCP Server")
        self.setup_routes()
        self.calendar_service = None
        self.setup_calendar_service()
        
    def setup_calendar_service(self):
        """Setup Google Calendar service"""
        try:
            creds = None
            if os.path.exists(TOKEN_FILE):
                with open(TOKEN_FILE, 'rb') as token:
                    creds = pickle.load(token)
            
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    if os.path.exists(CREDENTIALS_FILE):
                        flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
                        creds = flow.run_local_server(port=0)
                    else:
                        print(f"Warning: {CREDENTIALS_FILE} not found. Calendar features will be disabled.")
                        return
                
                with open(TOKEN_FILE, 'wb') as token:
                    pickle.dump(creds, token)
            
            self.calendar_service = build('calendar', 'v3', credentials=creds)
            print("Google Calendar service initialized successfully")
            
        except Exception as e:
            print(f"Error setting up Google Calendar service: {e}")
            self.calendar_service = None
    
    def setup_routes(self):
        """Setup FastAPI routes"""
        
        @self.app.post("/mcp/tools/call")
        async def call_tool(request: MCPRequest):
            """Handle MCP tool calls"""
            try:
                if request.method == "get_current_datetime":
                    return await self.get_current_datetime()
                elif request.method == "get_upcoming_events":
                    return await self.get_upcoming_events(request.params or {})
                elif request.method == "classify_task":
                    return await self.classify_task(request.params or {})
                else:
                    raise HTTPException(status_code=400, detail=f"Unknown method: {request.method}")
            except Exception as e:
                return MCPResponse(error=str(e))
        
        @self.app.get("/mcp/tools/list")
        async def list_tools():
            """List available MCP tools"""
            return {
                "tools": [
                    {
                        "name": "get_current_datetime",
                        "description": "Get the current date and time",
                        "parameters": {}
                    },
                    {
                        "name": "get_upcoming_events",
                        "description": "Get upcoming calendar events",
                        "parameters": {
                            "max_results": {"type": "integer", "default": 10},
                            "days_ahead": {"type": "integer", "default": 7}
                        }
                    },
                    {
                        "name": "classify_task",
                        "description": "Classify a task and extract structured information",
                        "parameters": {
                            "task_description": {"type": "string", "required": True}
                        }
                    }
                ]
            }
        
        @self.app.get("/health")
        async def health_check():
            """Health check endpoint"""
            return {"status": "healthy", "calendar_service": self.calendar_service is not None}
    
    async def get_current_datetime(self) -> MCPResponse:
        """Get current date and time"""
        now = datetime.now()
        return MCPResponse(result={
            "datetime": now.isoformat(),
            "date": now.strftime("%d.%m.%Y"),
            "time": now.strftime("%H:%M"),
            "day_of_week": now.strftime("%A"),
            "timestamp": now.timestamp()
        })
    
    async def get_upcoming_events(self, params: Dict[str, Any]) -> MCPResponse:
        """Get upcoming calendar events"""
        if not self.calendar_service:
            return MCPResponse(error="Calendar service not available")
        
        try:
            max_results = params.get("max_results", 10)
            days_ahead = params.get("days_ahead", 7)
            
            now = datetime.utcnow()
            end_time = now + timedelta(days=days_ahead)
            
            events_result = self.calendar_service.events().list(
                calendarId='primary',
                timeMin=now.isoformat() + 'Z',
                timeMax=end_time.isoformat() + 'Z',
                maxResults=max_results,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            
            formatted_events = []
            for event in events:
                start = event['start'].get('dateTime', event['start'].get('date'))
                end = event['end'].get('dateTime', event['end'].get('date'))
                
                formatted_events.append({
                    "summary": event.get('summary', 'No title'),
                    "start": start,
                    "end": end,
                    "attendees": [attendee.get('email') for attendee in event.get('attendees', [])],
                    "description": event.get('description', ''),
                    "location": event.get('location', '')
                })
            
            return MCPResponse(result={
                "events": formatted_events,
                "count": len(formatted_events),
                "time_range": {
                    "from": now.isoformat(),
                    "to": end_time.isoformat()
                }
            })
            
        except Exception as e:
            return MCPResponse(error=f"Error fetching calendar events: {str(e)}")
    
    async def classify_task(self, params: Dict[str, Any]) -> MCPResponse:
        """Classify a task using the Gemini-based classifier"""
        try:
            task_description = params.get("task_description")
            if not task_description:
                return MCPResponse(error="task_description is required")
            
            # Get current date from the datetime function
            current_datetime_response = await self.get_current_datetime()
            if current_datetime_response.error or not current_datetime_response.result:
                return MCPResponse(error=f"Error getting current date: {current_datetime_response.error or 'No result'}")
            
            current_date = current_datetime_response.result["date"]
            
            # Import the classifier here to avoid circular imports
            from task_classifier_gemini import TaskClassifierGemini
            
            classifier = TaskClassifierGemini()
            result = classifier.classify_task(task_description, current_date=current_date)
            
            return MCPResponse(result=result)
            
        except Exception as e:
            return MCPResponse(error=f"Error classifying task: {str(e)}")

def main():
    """Main function to run the MCP server"""
    server = TaskClassifierMCP()
    
    import uvicorn
    uvicorn.run(
        server.app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )

if __name__ == "__main__":
    main() 